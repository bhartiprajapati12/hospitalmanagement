package hospial.management;

import hospial.management.system.connection;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.util.Date;
import java.util.SimpleTimeZone;
import java.util.Vector;

public class NEW_PATIENT extends JFrame implements ActionListener {

    JComboBox comboBox;

    JTextField textFieldNumber, textName, textFieldDisease, textFieldDeposite;

    JRadioButton r1, r2;

    JLabel date;

    Choice c1;

    JButton b1, b2;

    public NEW_PATIENT() {

        JPanel panel = new JPanel();
        panel.setBounds(5, 5, 800, 500);
        panel.setBackground(new Color(9, 241, 248));
        panel.setLayout(null);
        add(panel);

        //ImageIcon imageIcon = new ImageIcon("hospital.management.system.NEW_PATIENT/patient.jpg");
        ImageIcon imageIcon = new ImageIcon(ClassLoader.getSystemResource("hospial//management//system//patient.jpg"));
        Image image = imageIcon.getImage().getScaledInstance(400, 290, Image.SCALE_SMOOTH);
        ImageIcon imageIcon1 = new ImageIcon(image);
        JLabel label = new JLabel(imageIcon1);
        label.setBounds(220, 150, 800, 200);
        panel.add(label);

        JLabel labelName = new JLabel("NEW PATIENT FORM");
        labelName.setBounds(118, 11, 260, 53);
        labelName.setFont(new Font("tahoma", Font.BOLD, 20));
        panel.add(labelName);

        JLabel labelID = new JLabel("ID :");
        labelID.setBounds(35, 76, 200, 14);
        labelID.setFont(new Font("tahoma", Font.BOLD, 14));
        labelID.setBackground(Color.white);
        panel.add(labelID);

        comboBox = new JComboBox(new String[]{"Aadhar card", "Voter Id", "Driving Licence"});
        comboBox.setBounds(190, 73, 150, 20);
        comboBox.setBackground(new Color(3, 45, 48));
        comboBox.setForeground(Color.yellow);
        comboBox.setFont(new Font("tahoma", Font.BOLD, 14));
        panel.add(comboBox);

        JLabel labelNumber = new JLabel("Number :");
        labelNumber.setBounds(35, 120, 200, 14);
        labelNumber.setBackground(Color.white);
        labelNumber.setFont(new Font("tahoma", Font.BOLD, 14));
        panel.add(labelNumber);

        textFieldNumber= new JTextField();
        textFieldNumber.setBounds(190, 120, 150, 20);
        textFieldNumber.setBackground(Color.WHITE);
        textFieldNumber.setFont(new Font("tahoma", Font.BOLD, 14));
        panel.add(textFieldNumber);

        JLabel labelName1 = new JLabel("Name :");
        labelName1.setBounds(35, 165, 200, 14);
        labelName1.setBackground(Color.WHITE);
        labelName1.setFont(new Font("tahoma", Font.BOLD, 14));
        panel.add(labelName1);

        textName = new JTextField();
        textName.setBounds(190, 160, 150, 20);
        textName.setFont(new Font("tahoma", Font.BOLD, 14));
        textName.setBackground(Color.WHITE);
        panel.add(textName);

        JLabel labelGender = new JLabel("Gender :");
        labelGender.setBounds(35, 210, 200, 14);
        labelGender.setBackground(Color.WHITE);
        labelGender.setFont(new Font("tahoma", Font.BOLD, 14));
        panel.add(labelGender);
        r1 = new JRadioButton("male");
        r1.setBackground(Color.WHITE);
        r1.setBounds(190, 210, 70, 15);
        r1.setFont(new Font("tahoma", Font.BOLD, 15));
        panel.add(r1);

        r2 = new JRadioButton("Female");
        r2.setBackground(Color.WHITE);
        r2.setBounds(270, 210, 70, 15);
        r2.setFont(new Font("tahoma", Font.BOLD, 12));
        panel.add(r2);

        JLabel labelDisease = new JLabel("Disease :");
        labelDisease.setBounds(35, 260, 200, 14);
        labelDisease.setFont(new Font("tahoma", Font.BOLD, 14));
        labelDisease.setBackground(Color.WHITE);
        panel.add(labelDisease);

        textFieldDisease= new JTextField();
        textFieldDisease.setBounds(190, 260, 150, 20);
        textFieldDisease.setFont(new Font("tahoma", Font.BOLD, 14));
        textFieldDisease.setBackground(Color.WHITE);
        panel.add(textFieldDisease);

        JLabel labelRoom = new JLabel("ROOM :");
        labelRoom.setBounds(35, 310, 150, 14);
        labelRoom.setBackground(Color.WHITE);
        labelRoom.setFont(new Font("tahoma", Font.BOLD, 14));
        panel.add(labelRoom);

c1 = new Choice();
try {
    connection c = new connection();
    ResultSet resultSet = c.statement.executeQuery("select * from room");
    while (resultSet.next()){
        c1.add(resultSet.getString("room_no"));
    }
}catch (Exception e){
    e.printStackTrace();
}
c1.setBounds(190,310,150,20);
c1.setFont(new Font("tahoma",Font.BOLD,14));
c1.setForeground(Color.WHITE);
c1.setBackground(new Color(3,45,48));
panel.add(c1);


        JLabel labeltime = new JLabel("TIME :");
        labeltime.setBounds(35, 360, 150, 14);
        labeltime.setBackground(Color.WHITE);
        labeltime.setFont(new Font("tahoma", Font.BOLD, 14));
        panel.add(labeltime);

        Date date1 = new Date();
        date1 = new Date();

        date = new JLabel("" + date1);
        date.setBounds(190, 360, 250, 20);
        date.setBackground(Color.WHITE);
        date.setFont(new Font("tahoma", Font.BOLD, 14));
        panel.add(date);


        JLabel labeldeposite = new JLabel("Deposite :");
        labeldeposite.setBounds(35, 410, 150, 14);
        labeldeposite.setBackground(Color.WHITE);
        labeldeposite.setFont(new Font("tahoma", Font.BOLD, 14));
        panel.add(labeldeposite);

        textFieldDeposite = new JTextField();
        textFieldDeposite.setBounds(190, 410, 150, 20);
        textFieldDeposite.setFont(new Font("tahoma", Font.BOLD, 14));
        textFieldDeposite.setBackground(Color.WHITE);
        panel.add(textFieldDeposite);

        b1 = new JButton("ADD");
        b1.setBounds(130, 470, 120, 30);
        //b1.setFont(new Font("tahoma",Font.BOLD,14));
        b1.setBackground(Color.BLACK);
        b1.setForeground(new Color(0xFFFFFF));
        b1.addActionListener(this);
        panel.add(b1);

        b2 = new JButton("CANCEL");
        b2.setBounds(350, 470, 120, 30);
        //b2.setFont(new Font("tahoma",Font.BOLD,14));
        b2.setBackground(Color.BLACK);
        b2.setForeground(new Color(0xD6E6E6));
        b2.addActionListener(this);
        panel.add(b2);

        setUndecorated(true);

        setSize(870, 570);
        setLocation(350, 180);
        setVisible(true);
        setLayout(null);

    }

    public static void main(String[] args) {

        new NEW_PATIENT();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource()== b1){
            connection c = new connection();
            String redioBTN = null;
            if (r1.isSelected()){
                redioBTN = "Male";
            }
            else if(r2.isSelected()){
                redioBTN = "Female";
            }
            String s1 = (String) comboBox.getSelectedItem();
            String s2 = textFieldNumber.getText();
            String s3 = textName.getText();
            String s4 = redioBTN;
            String s5 = textFieldDisease.getText();
            String s6 = c1.getSelectedItem();
            String s7 = date.getText();
            String s8 = textFieldDeposite.getText();

            try {
                String q = "insert into Patient_infor values('"+s1+"','"+s2+"','"+s3+"','"+s4+"','"+s5+"','"+s6+"','"+s7+"','"+s8+"')";
                String q1 = "update room set Availability = 'Occupied' where room_no = "+s6;
                c.statement.executeUpdate(q);
                c.statement.executeUpdate(q1);
                JOptionPane.showMessageDialog(null,"Added Successfully");
                setVisible(false);

            }catch (Exception E){
                E.printStackTrace();
            }


        }else {
            setVisible(false);
        }


    }
}

