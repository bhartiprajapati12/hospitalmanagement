package hospial.management.system;

import net.proteanit.sql.DbUtils;

import javax.swing.*;
import javax.swing.event.AncestorEvent;
import javax.swing.event.AncestorListener;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;

public class Hospital_Ambulance extends Frame {

    JTable table;

    public Hospital_Ambulance(){

        JPanel panel = new JPanel();
        panel.setBounds(5,5,890,590);
        panel.setBackground(new Color(9,241,248));
        panel.setLayout(null);
        add(panel);

        table = new JTable();
        table.setBounds(10,60,900,350);
        table.setBackground(new Color(9,241,248));
        panel.add(table);

        try{
            connection c = new connection();
            String q = "select * from ambulance";
            ResultSet resultSet = c.statement.executeQuery(q);
            table.setModel(DbUtils.resultSetToTableModel(resultSet));

        }catch (Exception E) {
            E.printStackTrace();

        }
        JLabel label = new JLabel("Name");
        label.setBounds(10,10,100,20);
        label.setFont(new Font("tahoma",Font.BOLD,15));
        panel.add(label);

        JLabel label1 = new JLabel("Gender");
        label1.setBounds(200,10,100,20);
        label1.setFont(new Font("tahoma",Font.BOLD,15));
        panel.add(label1);

        JLabel label2 = new JLabel("Car Name");
        label2.setBounds(370,10,100,20);
        label2.setFont(new Font("tahoma",Font.BOLD,15));
        panel.add(label2);

        JLabel label3 = new JLabel("Available");
        label3.setBounds(550,10,100,20);
        label3.setFont(new Font("tahoma",Font.BOLD,15));
        panel.add(label3);

        JLabel label4 = new JLabel("Location");
        label4.setBounds(730,10,100,20);
        label4.setFont(new Font("tahoma",Font.BOLD,15));
        panel.add(label4);

        JButton back = new JButton("BACK");
        back.setBounds(360,450,120,30);
        back.setBackground(Color.BLACK);
        back.setForeground(Color.WHITE);
        back.setFont(new Font("tahoma",Font.BOLD,15));
        panel.add(back);
        back.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
            }
        });


        setUndecorated(true);

        setSize(900,600);
        setLayout(null);
        setVisible(true);
        setLocation(350,180);

    }

    public static void main(String[] args) {
        new Hospital_Ambulance();
    }
}
