package hospial.management.system;

import net.proteanit.sql.DbUtils;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;

public class Department extends JFrame {

    public Department(){

        JPanel panel = new JPanel();
        panel.setBounds(5,5,790,550);
        panel.setBackground(new Color(9,241,248));
        panel.setLayout(null);
        add(panel);

        JTable table = new JTable();
        table.setBounds(5,50,700,350);
        table.setBackground(new Color(9,241,248));
        table.setFont(new Font("tahoma",Font.BOLD,15));
        panel.add(table);

        try{

            connection c = new connection();
            String q = "select * from Department";
            ResultSet resultSet = c.statement.executeQuery(q);
            table.setModel(DbUtils.resultSetToTableModel(resultSet));
        }catch (Exception e){
            e.printStackTrace();
        }

        JLabel label = new JLabel("Department");
        label.setBounds(15,10,100,20);
        label.setFont(new Font("tahoma",Font.BOLD,15));
        panel.add(label);

        JLabel label1 = new JLabel("Phone_No");
        label1.setBounds(355,10,80,20);
        label1.setFont(new Font("tahoma",Font.BOLD,15));
        panel.add(label1);

        JButton button = new JButton("BACK");
        button.setBounds(300,410,120,30);
        button.setBackground(Color.BLACK);
        button.setForeground(Color.WHITE);
        panel.add(button);
        button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
            }
        });

        setUndecorated(true);


        setSize(800,560);
        setLocation(350,180);
        setLayout(null);
        setVisible(true);
    }

    public static void main(String[] args) {

        new Department();
    }
}
