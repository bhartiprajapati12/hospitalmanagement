package hospial.management.system;

import net.proteanit.sql.DbUtils;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;

public class Search_Room extends Frame {

    Choice choice;
    JTable table;

    public Search_Room(){

        JPanel panel = new JPanel();
        panel.setBounds(5,5, 690,490);
        panel.setBackground(new Color(9,241,248));
        panel.setLayout(null);
        add(panel);

         JLabel For = new JLabel("Search For Room");
         For.setBounds(250,10,186,31);
         For.setForeground(Color.WHITE);
         For.setFont(new Font("tahoma",Font.BOLD,20));
         panel.add(For);

        JLabel status = new JLabel("Status :");
        status.setBounds(70,73,80,20);
        status.setForeground(Color.WHITE);
        status.setFont(new Font("tahoma",Font.BOLD,15));
        panel.add(status);

        choice = new Choice();
        choice.setBounds(170,70,120,20);
        choice.add("Available");
        choice.add("Occupied");
        panel.add(choice);

        table = new JTable();
        table.setBounds(0,187,700,210);
        table.setBackground(new Color(9,241,248));
        table.setForeground(Color.WHITE);
        table.setFont(new Font("tahoma",Font.PLAIN,15));
        panel.add(table);

        try{
            connection c = new connection();
            String q = "select * from room";
            ResultSet resultSet = c.statement.executeQuery(q);
            table.setModel(DbUtils.resultSetToTableModel(resultSet));
        }catch (Exception e){
            e.printStackTrace();
        }

        JLabel room = new JLabel("Room No");
        room.setBounds(2,150,100,20);
        room.setFont(new Font("tahoma",Font.BOLD,15));
        room.setForeground(Color.WHITE);
        panel.add(room);

        JLabel available = new JLabel("Availability");
        available.setBounds(180,150,100,20);
        available.setFont(new Font("tahoma",Font.BOLD,15));
        available.setForeground(Color.WHITE);
        panel.add(available);

        JLabel price = new JLabel("Price");
        price.setBounds(360,150,100,20);
        price.setFont(new Font("tahoma",Font.BOLD,15));
        price.setForeground(Color.WHITE);
        panel.add(price);

        JLabel bed = new JLabel("Bed Type");
        bed.setBounds(530,150,100,20);
        bed.setFont(new Font("tahoma",Font.BOLD,15));
        bed.setForeground(Color.WHITE);
        panel.add(bed);

        JButton search = new JButton("SEARCH");
        search.setBounds(150,420,120,25);
        search.setBackground(Color.BLACK);
        search.setForeground(Color.WHITE);
        panel.add(search);
        search.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String q = "select * from Room where Availability = '"+choice.getSelectedItem()+"'";
                try{
                    connection c = new connection();
                    ResultSet resultSet = c.statement.executeQuery(q);
                    table.setModel(DbUtils.resultSetToTableModel(resultSet));
                }catch (Exception E){
                    E.printStackTrace();
                }
            }
        });

        JButton back = new JButton("BACK");
        back.setBounds(400,420,120,25);
        back.setBackground(Color.BLACK);
        back.setForeground(Color.WHITE);
        panel.add(back);
        back.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
            }
        });

setUndecorated(true);
        setSize(700,500);
        setLayout(null);
        setLocation(400,250);
        setVisible(true);

    }
    public static void main(String[] args) {
        new Search_Room();
    }
}
