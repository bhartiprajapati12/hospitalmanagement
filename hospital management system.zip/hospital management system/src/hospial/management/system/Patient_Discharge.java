package hospial.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.util.Date;
import java.util.Vector;


public class Patient_Discharge extends JFrame {

    JTextField textFieldNumber; JComboBox comboBox; JLabel date;

    public Patient_Discharge(){

        JPanel panel = new JPanel();
        panel.setBounds(5,5,890,590);
        panel.setBackground(new Color(9,241,248));
        panel.setLayout(null);
        add(panel);

        JLabel label = new JLabel("CHECK OUT");
        label.setBounds(118,11,260,53);
        label.setFont(new Font("tahoma",Font.BOLD,20));
        label.setForeground(Color.WHITE);
        panel.add(label);

        JLabel label1 = new JLabel("patient Id :");
        label1.setBounds(35,100,150,20);
        label1.setFont(new Font("tahoma",Font.BOLD,15));
        label1.setForeground(Color.WHITE);
        panel.add(label1);

        Choice choice = new Choice();
        choice.setBounds(190,100,150,25);
        panel.add(choice);

        try{
            connection c = new connection();
            ResultSet resultSet = c.statement.executeQuery("select * from Patient_infor");
            while (resultSet.next()){
                choice.add(resultSet.getString("number"));
            }
        }catch (Exception e){
            e.printStackTrace();
        }

        JLabel label2 = new JLabel("Room Number :");
        label2.setBounds(35,180,200,20);
        label2.setFont(new Font("tahoma",Font.BOLD,15));
        label2.setForeground(Color.WHITE);
        panel.add(label2);

        JLabel RNo = new JLabel();
        RNo.setBounds(190,180,150,20);
        RNo.setFont(new Font("tahoma",Font.BOLD,15));
        RNo.setForeground(Color.WHITE);
        panel.add(RNo);


//        textFieldNumber = new JTextField();
//        textFieldNumber.setBounds(190,200,150,20);
//        textFieldNumber.setBackground(Color.WHITE);
//        textFieldNumber.setFont(new Font("tahoma",Font.BOLD,14));
//        panel.add(textFieldNumber);

        JLabel label3 = new JLabel(" In Time :");
        label3.setBounds(35,260,200,20);
        label3.setFont(new Font("tahoma",Font.BOLD,15));
        label3.setForeground(Color.WHITE);
        panel.add(label3);

        JLabel INTime = new JLabel();
        INTime.setBounds(190,260,250,20);
        INTime.setFont(new Font("tahoma",Font.BOLD,15));
        INTime.setForeground(Color.WHITE);
        panel.add(INTime);


//        Date date1 = new Date();
//        date1 = new Date();
//
//        date = new JLabel(" "+ date1);
//        date.setBounds(190,280,300,20);
//        date.setBackground(Color.WHITE);
//        date.setFont(new Font("tahoma",Font.BOLD,14));
//        panel.add(date);

        JLabel label4 = new JLabel(" Out Time :");
        label4.setBounds(35,340,200,30);
        label4.setFont(new Font("tahoma",Font.BOLD,15));
        label4.setForeground(Color.WHITE);
        panel.add(label4);

        Date date = new Date();

        JLabel OUTTime = new JLabel(""+date);
        OUTTime.setBounds(190,340,250,20);
        OUTTime.setFont(new Font("tahoma",Font.BOLD,15));
        OUTTime.setForeground(Color.WHITE);
        panel.add(OUTTime);


//        Date date2 = new Date();
//        date2 = new Date();
//
//        date = new JLabel(" "+ date2);
//        date.setBounds(190,380,300,30);
//        date.setBackground(Color.WHITE);
//        date.setFont(new Font("tahoma",Font.BOLD,14));
//        panel.add(date);

        JButton discharge = new JButton("Discharge");
        discharge.setBounds(35,470,150,30);
        discharge.setBackground(Color.BLACK);
        discharge.setForeground(Color.WHITE);
        discharge.setFont(new Font("tahoma",Font.BOLD,15));
        panel.add(discharge);
        discharge.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                connection c = new connection();
                try{
                    c.statement.executeUpdate("delete from Patient_infor where number = '"+choice.getSelectedItem()+"'");
                    c.statement.executeUpdate("update room set Availability = 'Available' where room_no = '"+ RNo.getText()+"'");
                    JOptionPane.showMessageDialog(null,"Done");
                    setVisible(false);
                }catch (Exception E){
                    E.printStackTrace();
                }
            }
        });


        JButton Check = new JButton("CHECK");
        Check.setBounds(340,470,150,30);
        Check.setBackground(Color.BLACK);
        Check.setForeground(Color.WHITE);
        Check.setFont(new Font("tahoma",Font.BOLD,15));
        panel.add(Check);
        Check.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                connection c = new connection();
                try {
                    ResultSet resultSet = c.statement.executeQuery("select * from Patient_infor where number = '" + choice.getSelectedItem() + "'");
                    while (resultSet.next()) {
                        RNo.setText((resultSet.getString("Room_Number")));
                        INTime.setText(resultSet.getString("Time"));
                    }
                } catch (Exception E) {
                    E.printStackTrace();
                }
            }
        });



        JButton Back = new JButton("Back");
        Back.setBounds(600,470,150,30);
        Back.setBackground(Color.BLACK);
        Back.setForeground(Color.WHITE);
        Back.setFont(new Font("tahoma",Font.BOLD,15));
        panel.add(Back);
        Back.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
            }
        });


setUndecorated(true);

        setSize(900,600);
        setLocation(350,180);
        setLayout(null);
        setVisible(true);
    }

    public static void main(String[] args) {

        new Patient_Discharge();
    }
}
