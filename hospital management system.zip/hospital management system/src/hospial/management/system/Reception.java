package hospial.management.system;

import hospial.management.NEW_PATIENT;
import hospial.management.ROOM;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Reception extends JFrame {
    Reception(){

        JPanel panel = new JPanel();
        panel.setLayout(null);
        panel.setBounds(5,160,1525,670);
        panel.setBackground(new Color(225, 37, 222));
        panel.setVisible(true);
        add(panel);


         JPanel panel1= new JPanel();
         panel1.setLayout(null);
         panel1.setBackground(new Color(225, 37, 222));
         panel1.setBounds(5,5,1525,150);
         add(panel1);


        ImageIcon i1 = new ImageIcon("C://Users//hp//IdeaProjects//hospital management system//src//hospial//management//system//dr.jpg");
        Image image= i1.getImage().getScaledInstance(350,300,Image.SCALE_DEFAULT);
        ImageIcon i2 = new ImageIcon(image);
        JLabel label = new JLabel(i2);
        label.setBounds(1270,10,250,250);
        panel1.add(label);

        //ImageIcon i11 = new ImageIcon("C:\\Users\\hp\\IdeaProjects\\hospital management system\\src\\hospial\\management\\system\\ambulance.png");
        ImageIcon i11 = new ImageIcon (ClassLoader.getSystemResource("hospial//management//system//ambulance.png"));
        Image image1= i11.getImage().getScaledInstance(350,350,Image.SCALE_DEFAULT);
        ImageIcon i22 = new ImageIcon(image1);
        JLabel label1 = new JLabel(i22);
        label1.setBounds(100,50,300,300);
        label1.setVisible(true);
        label1.setLayout(null);
        panel1.add(label1);


         JButton bt1 = new JButton("Add New Patient");
         bt1.setBounds(30,30,200,40);
         bt1.setFont(new Font("serif",Font.BOLD,15));
         panel1.add(bt1);
        bt1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

            new NEW_PATIENT();
            }
        });

        JButton bt2 = new JButton("ROOM");
        bt2.setBounds(30,110,200,40);
        bt2.setFont(new Font("serif(ref serif)",Font.BOLD,15));
        panel1.add(bt2);
        bt2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                new ROOM();


            }
        });

        JButton bt3 = new JButton("Department");
        bt3.setBounds(30,30,200,40);
        bt3.setFont(new Font("serif(ref serif)",Font.BOLD,15));
        panel.add(bt3);
        bt3.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new Department();

            }
        });



        JButton bt4 = new JButton("All Employe Inormation");
        bt4.setBounds(30,100,200,40);
        bt4.setFont(new Font("serif(ref serif)",Font.BOLD,15));
        panel.add(bt4);
        bt4.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new Employee_info();

            }
        });



        JButton bt5 = new JButton("Patient Info");
        bt5.setBounds(30,190,200,40);
        bt5.setFont(new Font("serif(ref serif)",Font.BOLD,15));
        panel.add(bt5);
        bt5.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new All_Patient_info();

            }
        });



        JButton bt6 = new JButton("Patient Discharge");
        bt6.setBounds(30,270,200,40);
        bt6.setFont(new Font("serif(ref serif)",Font.BOLD,15));
        panel.add(bt6);
        bt6.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new Patient_Discharge();

            }
        });




        JButton bt7 = new JButton("Update Patient Details");
        bt7.setBounds(30,350,200,40);
        bt7.setFont(new Font("serif(ref serif)",Font.BOLD,15));
        panel.add(bt7);
        bt7.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new update_patient_details();

            }
        });



        JButton bt8 = new JButton("Search Room");
        bt8.setBounds(30,450,200,40);
        bt8.setFont(new Font("serif(ref serif)",Font.BOLD,15));
        panel.add(bt8);
        bt8.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new Search_Room();


            }
        });




        JButton bt9 = new JButton("Hospital Ambulance");
        bt9.setBounds(30,550,200,40);
        bt9.setFont(new Font("serif(ref serif)",Font.BOLD,15));
        panel.add(bt9);
        bt9.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new Hospital_Ambulance();

            }
        });



        JButton bt10 = new JButton("Log Out");
        bt10.setBounds(1250,550,200,40);
        bt10.setBackground(new Color(234, 241, 15));
        bt10.setFont(new Font("tahoma",Font.BOLD,15));
        bt10.setForeground(Color.BLACK);
        panel.add(bt10);
        bt10.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
                new login();

            }
        });








        setSize(1950,1090);
        setVisible(true);
        getContentPane().setBackground(new Color(214, 230, 230));
        setLayout(null);
    }
    public static void main(String[] args){
        new Reception();
    }
}
