package hospial.management.system;

import net.proteanit.sql.DbUtils;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;

public class Employee_info extends JFrame {

    public Employee_info(){

        JPanel panel = new JPanel();
        panel.setBounds(5,5,790,590);
        panel.setBackground(new Color(9,241,248));
        panel.setLayout(null);
        add(panel);

        JTable table = new JTable();
        table.setBounds(0,50,750,350);
        table.setBackground(new Color(9,241,248));
        table.setFont(new Font("tahoma",Font.BOLD,15));
        panel.add(table);

        try{
            connection c = new connection();
            String q = "select * from Employe_info";
            ResultSet resultSet = c.statement.executeQuery(q);
            table.setModel(DbUtils.resultSetToTableModel(resultSet));

        }catch (Exception e){
            e.printStackTrace();
        }


        JLabel label = new JLabel("Name");
        label.setBounds(5,10,100,20);
        label.setFont(new Font("tahoma",Font.BOLD,15));
        panel.add(label);

        JLabel label1 = new JLabel("Age");
        label1.setBounds(150,10,80,20);
        label1.setFont(new Font("tahoma",Font.BOLD,15));
        panel.add(label1);

        JLabel label2 = new JLabel("Phone No");
        label2.setBounds(300,10,100,20);
        label2.setFont(new Font("tahoma",Font.BOLD,15));
        panel.add(label2);

        JLabel label3 = new JLabel("Salary");
        label3.setBounds(450,10,100,20);
        label3.setFont(new Font("tahoma",Font.BOLD,15));
        panel.add(label3);

        JLabel label4 = new JLabel("Gmail ID");
        label4.setBounds(600,10,100,20);
        label4.setFont(new Font("tahoma",Font.BOLD,15));
        panel.add(label4);

        JButton button = new JButton("BACK");
        button.setBounds(300,400,120,30);
        button.setBackground(Color.BLACK);
        button.setForeground(Color.WHITE);
        panel.add(button);
        button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
            }
        });

        setUndecorated(true);

        setSize(800,600);
        setLocation(350,180);
        setLayout(null);
        setVisible(true);


    }

    public static void main(String[] args) {
        new Employee_info();
    }
}
